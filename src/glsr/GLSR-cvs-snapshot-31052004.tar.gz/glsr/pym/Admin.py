#!/usr/bin/env python2
#
# Copyright 2004 Ian Leitch
# Copyright 1999-2004 Gentoo Technologies, Inc.
# Distributed under the terms of the GNU General Public License v2
#
# $Header: /glsr/glsr/pym/Admin.py,v 1.2 2004/04/25 01:49:23 shadfiel Exp $
#

#import MySQLdb
import Function
import Config
from time import strftime, gmtime

__modulename__ = "Admin"
__productname__ = "glsr"



def GetUser
