# Copyright 2004 Ian Leitch
# Copyright 1999-2004 Gentoo Technologies, Inc.
# Distributed under the terms of the GNU General Public License v2
#
# $Id: Template.py,v 1.2 2004/04/25 01:49:23 shadfiel Exp $

import sys
import string

import Config
import Function

__modulename__ = "Template"

class New:

    def __init__(self):
        
	self.Template = ""
	self.Contents = []
	self.Output = []

    def _Read(self):

        try:
            self.Contents = open(self.Template, "r").readlines()
        except IOError, errmsg:
            Function.logwrite("ERROR: %s: Failed to open %s for reading '%s'" % (__modulename__, self.Template, errmsg), "Error")
	    print "<html>\n<head>\n</head>\n<body>"
            print "<font size=3><b>FATAL ERROR: Failed to open template '%s' for reading.</b><br>Please contact %s with the given error message.</font>" % (file, Config.Contact)
	    print "</body>\n</html>"
	    sys.exit(1)

        return self.Contents
	
    def _Clear(self):

        self.Template = ""
	self.Contents = []
	self.Output = []
	
    def Compile(self, Template, SubTerms = []):

        self.Template = Template
        del Template
        self._Read()
	
        for line in self.Contents:
            for term in SubTerms:
                if "{"+term+"}" in line:
                    line = string.replace(line, "{"+term+"}", SubTerms[term])
            self.Output.append(line.strip("\n"))

    def Print(self):

        if self.Template == "":
	     raise TemplateError, "No compiled template data found."

	print "\n".join(self.Output)

        self._Clear()

class TemplateError(Exception): pass
