__all__ = {
    "Page_Main": ["main"],
    "Page_News": ["news"],
    "Page_User": ["user"],
    "Page_Script": ["script"] ,
    "Page_Language": ["language"],
    "Page_Category": ["category"],
    "Page_Statistics": ["stat"]
    }
                                                                                
failover = {"module": "Page_Main", "page": "main"}

