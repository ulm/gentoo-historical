#!/usr/bin/env python2
#
# Copyright 2004 Ian Leitch
# Copyright 1999-2004 Gentoo Technologies, Inc.
# Distributed under the terms of the GNU General Public License v2
#
# $Header: /var/cvsroot/gentoo/src/glsr/src/pym/Admin.py,v 1.1.1.1 2004/06/04 06:38:34 port001 Exp $
#

#import MySQLdb
import Function
import Config
from time import strftime, gmtime

__modulename__ = "Admin"
__productname__ = "glsr"



def GetUser
