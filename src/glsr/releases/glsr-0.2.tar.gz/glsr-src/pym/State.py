# Copyright 2004 Ian Leitch
# Copyright 2004 Scott Hadfield
# Copyright 1999-2004 Gentoo Technologies, Inc.
# Distributed under the terms of the GNU General Public License v2
#
# $Id: State.py,v 1.3 2004/11/10 16:33:33 port001 Exp $
#

__modulename__ = "State"

ActiveThreads = 0

HTMLHeadersSent = False
HeaderTmplSent = False
